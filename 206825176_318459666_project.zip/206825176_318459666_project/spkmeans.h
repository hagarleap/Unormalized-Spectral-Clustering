

double** wam_func(double** data_matrix, int n, int dim2);
double** ddg_func( double** weight_mat, int n);
double** gl_func(double** weight_mat, double** diag_degree_mat, int n);
double** jacobi_func(double** A, int n);

